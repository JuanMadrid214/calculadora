import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'calculadora';

  mostrar = '0';
  cvalue = '';

  escribir(value:string){
    this.cvalue = this.cvalue + value;
    this.mostrar = this.cvalue;
  }

  limpiar(){
   this.cvalue = '';
   this.mostrar = '0'; 
  }


  
}
